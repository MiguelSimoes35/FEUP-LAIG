/**
 * My Animation
 * @param scene
 */

class MyAnimation {
    constructor (scene) {
        this.scene = scene;
    }

    update(t){}

    apply(){}
}
